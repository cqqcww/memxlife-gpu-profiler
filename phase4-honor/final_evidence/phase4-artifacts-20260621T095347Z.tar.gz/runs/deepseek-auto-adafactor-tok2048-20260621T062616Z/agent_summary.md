# Agent Run Summary

- Run directory: `/workspace/runs/deepseek-auto-adafactor-tok2048-20260621T062616Z`
- Train events: `3`
- Validation events: `1`
- Average tokens/sec: `3092.42`

## Last Train Metrics

```json
{
  "backward_s": 0.24610065598972142,
  "cuda_allocated_mb": 11055.40087890625,
  "cuda_peak_allocated_mb": 14305.40185546875,
  "cuda_peak_reserved_mb": 18576.0,
  "cuda_reserved_mb": 18576.0,
  "data_s": 0.000611612806096673,
  "forward_s": 0.12816288601607084,
  "loss": 21.716068267822266,
  "lr": 1e-05,
  "optimizer_s": 0.18069663201458752,
  "step_time_s": 0.55685093998909,
  "tokens_per_sec": 3677.8244462335383
}
```

## Last Validation Metrics

```json
{
  "cuda_allocated_mb": 12075.4482421875,
  "cuda_peak_allocated_mb": 14305.40185546875,
  "cuda_peak_reserved_mb": 18576.0,
  "cuda_reserved_mb": 18576.0,
  "loss": 3.509953260421753,
  "perplexity": 33.44670446255037
}
```
