# Preflight Report

## Profiles

- Base config: `configs/base/causal_lm_tinystories.yaml`
- Model profile: `gpt2`
- Data profile: `tinystories`
- Notes: Base for small HuggingFace text dataset experiments. || model_profile: family=gpt-style-causal-lm | expected_memory=medium | Larger than distilgpt2; use smaller batch size or gradient accumulation if memory is tight. || data_profile: Small TinyStories subset for fast, coherent causal-LM experiments.

## Model And Data

- Model: `gpt2`
- Parameters: `124439808`
- Data source: `huggingface_dataset`
- Dataset/local path: `roneneldan/TinyStories`
- Available columns: `['text']`
- Text field found: `True`
- Cache enabled: `True`

## Runtime

- Device: `cuda`
- Mixed precision: `auto`
- Tokens per optimizer step: `256`
- CUDA available: `True`

## Recommendations

- none

## Warnings

- none
