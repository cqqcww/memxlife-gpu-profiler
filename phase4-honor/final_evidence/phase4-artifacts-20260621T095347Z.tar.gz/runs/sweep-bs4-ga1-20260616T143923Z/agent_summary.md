# Agent Run Summary

- Run directory: `/workspace/runs/sweep-bs4-ga1-20260616T143923Z`
- Train events: `12`
- Validation events: `2`
- Average tokens/sec: `20284.70`

## Last Train Metrics

```json
{
  "backward_s": 0.0251223020022735,
  "data_s": 0.00020976003725081682,
  "forward_s": 0.014675379963591695,
  "loss": 5.281970500946045,
  "lr": 2.9999999999999997e-05,
  "optimizer_s": 0.009906804072670639,
  "step_time_s": 0.050313143990933895,
  "tokens_per_sec": 20352.534522281458
}
```

## Last Validation Metrics

```json
{
  "loss": 5.366732960655575,
  "perplexity": 214.16204768852472
}
```
