# Agent Run Summary

- Run directory: `/workspace/runs/deepseek-auto-adafactor-tok512-20260621T062351Z`
- Train events: `3`
- Validation events: `1`
- Average tokens/sec: `1343.92`

## Last Train Metrics

```json
{
  "backward_s": 0.07511286507360637,
  "cuda_allocated_mb": 10594.74072265625,
  "cuda_peak_allocated_mb": 11144.458984375,
  "cuda_peak_reserved_mb": 13666.0,
  "cuda_reserved_mb": 13666.0,
  "data_s": 0.0005046860314905643,
  "forward_s": 0.040421014884486794,
  "loss": 7.885550498962402,
  "lr": 1e-05,
  "optimizer_s": 0.18053150200285017,
  "step_time_s": 0.29781495104543865,
  "tokens_per_sec": 1719.1883691624414
}
```

## Last Validation Metrics

```json
{
  "cuda_allocated_mb": 10849.7529296875,
  "cuda_peak_allocated_mb": 11144.458984375,
  "cuda_peak_reserved_mb": 13666.0,
  "cuda_reserved_mb": 13666.0,
  "loss": 8.631453514099121,
  "perplexity": 5605.219600314773
}
```
