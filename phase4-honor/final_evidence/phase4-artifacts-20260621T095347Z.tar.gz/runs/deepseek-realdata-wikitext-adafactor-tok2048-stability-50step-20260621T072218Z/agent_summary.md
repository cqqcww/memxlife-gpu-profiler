# Agent Run Summary

- Run directory: `/workspace/runs/deepseek-realdata-wikitext-adafactor-tok2048-stability-50step-20260621T072218Z`
- Train events: `10`
- Validation events: `5`
- Average tokens/sec: `3655.35`

## Last Train Metrics

```json
{
  "backward_s": 0.25013006501831114,
  "cuda_allocated_mb": 11055.40087890625,
  "cuda_peak_allocated_mb": 14305.40185546875,
  "cuda_peak_reserved_mb": 18828.0,
  "cuda_reserved_mb": 18828.0,
  "data_s": 0.000517203938215971,
  "forward_s": 0.1305279228836298,
  "loss": 6.488150119781494,
  "lr": 1e-05,
  "optimizer_s": 0.18155613890849054,
  "step_time_s": 0.5634184810332954,
  "tokens_per_sec": 3634.953536213472
}
```

## Last Validation Metrics

```json
{
  "cuda_allocated_mb": 12075.4482421875,
  "cuda_peak_allocated_mb": 14305.40185546875,
  "cuda_peak_reserved_mb": 18828.0,
  "cuda_reserved_mb": 18828.0,
  "loss": 6.937769412994385,
  "perplexity": 1030.469098513448
}
```
