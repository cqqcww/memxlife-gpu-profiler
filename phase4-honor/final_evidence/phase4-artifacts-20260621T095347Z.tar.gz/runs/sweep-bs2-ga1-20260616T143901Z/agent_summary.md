# Agent Run Summary

- Run directory: `/workspace/runs/sweep-bs2-ga1-20260616T143901Z`
- Train events: `12`
- Validation events: `2`
- Average tokens/sec: `15114.61`

## Last Train Metrics

```json
{
  "backward_s": 0.013826570939272642,
  "data_s": 0.00020882498938590288,
  "forward_s": 0.00944366108160466,
  "loss": 5.630406856536865,
  "lr": 2.9999999999999997e-05,
  "optimizer_s": 0.009832482086494565,
  "step_time_s": 0.033691583084873855,
  "tokens_per_sec": 15196.673860952147
}
```

## Last Validation Metrics

```json
{
  "loss": 5.736197878674763,
  "perplexity": 309.8839518972787
}
```
