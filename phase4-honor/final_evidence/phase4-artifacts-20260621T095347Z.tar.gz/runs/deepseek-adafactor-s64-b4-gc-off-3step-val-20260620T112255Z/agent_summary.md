# Agent Run Summary

- Run directory: `/workspace/runs/deepseek-adafactor-s64-b4-gc-off-3step-val-20260620T112255Z`
- Train events: `3`
- Validation events: `1`
- Average tokens/sec: `759.65`

## Last Train Metrics

```json
{
  "backward_s": 0.04322437779046595,
  "cuda_allocated_mb": 10513.35986328125,
  "cuda_peak_allocated_mb": 11060.35986328125,
  "cuda_peak_reserved_mb": 13010.0,
  "cuda_reserved_mb": 13010.0,
  "data_s": 0.0005029679741710424,
  "forward_s": 0.03429745393805206,
  "loss": 6.8088154792785645,
  "lr": 1e-05,
  "optimizer_s": 0.18048805091530085,
  "step_time_s": 0.25982933188788593,
  "tokens_per_sec": 985.2621262577919
}
```

## Last Validation Metrics

```json
{
  "cuda_allocated_mb": 10545.23681640625,
  "cuda_peak_allocated_mb": 11060.35986328125,
  "cuda_peak_reserved_mb": 13010.0,
  "cuda_reserved_mb": 13010.0,
  "loss": 10.742090225219727,
  "perplexity": 46262.6502851465
}
```
