# Agent Run Summary

- Run directory: `/workspace/runs/qwen-probe-s128-b1-gc-off-20260619T033035Z`
- Train events: `4`
- Validation events: `1`
- Average tokens/sec: `897.69`

## Last Train Metrics

```json
{
  "backward_s": 0.050379117019474506,
  "data_s": 0.0003458508290350437,
  "forward_s": 0.033144956920295954,
  "loss": 8.959257125854492,
  "lr": 0.0003,
  "optimizer_s": 0.05758042400702834,
  "step_time_s": 0.14218072802759707,
  "tokens_per_sec": 900.2626570821567
}
```

## Last Validation Metrics

```json
{
  "loss": 8.983927847325116,
  "perplexity": 7973.890911512749
}
```
