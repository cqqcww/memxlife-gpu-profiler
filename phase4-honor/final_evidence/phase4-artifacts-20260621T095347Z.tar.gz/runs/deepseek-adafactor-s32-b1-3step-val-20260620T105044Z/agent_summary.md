# Agent Run Summary

- Run directory: `/workspace/runs/deepseek-adafactor-s32-b1-3step-val-20260620T105044Z`
- Train events: `3`
- Validation events: `1`
- Average tokens/sec: `84.54`

## Last Train Metrics

```json
{
  "backward_s": 0.07870376203209162,
  "cuda_allocated_mb": 10437.35546875,
  "cuda_peak_allocated_mb": 10984.35546875,
  "cuda_peak_reserved_mb": 12292.0,
  "cuda_reserved_mb": 12292.0,
  "data_s": 0.00045872898772358894,
  "forward_s": 0.034583367174491286,
  "loss": 5.490993022918701,
  "lr": 1e-05,
  "optimizer_s": 0.18040575087070465,
  "step_time_s": 0.29549699695780873,
  "tokens_per_sec": 108.29213267628903
}
```

## Last Validation Metrics

```json
{
  "cuda_allocated_mb": 10441.357421875,
  "cuda_peak_allocated_mb": 10984.35546875,
  "cuda_peak_reserved_mb": 12292.0,
  "cuda_reserved_mb": 12292.0,
  "loss": 10.843353271484375,
  "perplexity": 51192.75368821885
}
```
