# Preflight Report

## Profiles

- Base config: `configs/cached_tinystories.yaml`
- Model profile: `none`
- Data profile: `none`
- Notes: none

## Model And Data

- Model: `distilgpt2`
- Parameters: `81912576`
- Data source: `huggingface_dataset`
- Dataset/local path: `roneneldan/TinyStories`
- Available columns: `['text']`
- Text field found: `True`
- Cache enabled: `True`

## Runtime

- Device: `cuda`
- Mixed precision: `off`
- Tokens per optimizer step: `2048`
- CUDA available: `True`

## Recommendations

- Gradient accumulation lowers memory pressure but adds extra forward/backward passes, so throughput may trail a true larger batch.

## Warnings

- none
