# Agent Run Summary

- Run directory: `/workspace/runs/sweep-bs4-ga2-20260616T144012Z`
- Train events: `12`
- Validation events: `2`
- Average tokens/sec: `22139.84`

## Last Train Metrics

```json
{
  "backward_s": 0.05195551097858697,
  "data_s": 0.00043278990779072046,
  "forward_s": 0.02965993294492364,
  "loss": 5.2080793380737305,
  "lr": 2.9999999999999997e-05,
  "optimizer_s": 0.009915522998198867,
  "step_time_s": 0.09248027298599482,
  "tokens_per_sec": 22145.263350489335
}
```

## Last Validation Metrics

```json
{
  "loss": 5.19067569006057,
  "perplexity": 179.58985902727957
}
```
