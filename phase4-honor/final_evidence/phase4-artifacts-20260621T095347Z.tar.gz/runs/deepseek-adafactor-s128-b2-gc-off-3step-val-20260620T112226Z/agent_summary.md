# Agent Run Summary

- Run directory: `/workspace/runs/deepseek-adafactor-s128-b2-gc-off-3step-val-20260620T112226Z`
- Train events: `3`
- Validation events: `1`
- Average tokens/sec: `756.23`

## Last Train Metrics

```json
{
  "backward_s": 0.043216350954025984,
  "cuda_allocated_mb": 10513.35986328125,
  "cuda_peak_allocated_mb": 11060.35986328125,
  "cuda_peak_reserved_mb": 12988.0,
  "cuda_reserved_mb": 12988.0,
  "data_s": 0.000526410061866045,
  "forward_s": 0.03302311315201223,
  "loss": 7.411380290985107,
  "lr": 1e-05,
  "optimizer_s": 0.180367365013808,
  "step_time_s": 0.25841016694903374,
  "tokens_per_sec": 990.673095499725
}
```

## Last Validation Metrics

```json
{
  "cuda_allocated_mb": 10577.11328125,
  "cuda_peak_allocated_mb": 11060.35986328125,
  "cuda_peak_reserved_mb": 12988.0,
  "cuda_reserved_mb": 12988.0,
  "loss": 9.981078147888184,
  "perplexity": 21613.602652418347
}
```
