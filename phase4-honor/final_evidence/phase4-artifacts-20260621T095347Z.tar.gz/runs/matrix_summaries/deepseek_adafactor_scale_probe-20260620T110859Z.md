# Matrix Summary: deepseek_adafactor_scale_probe

Compare DeepSeek Adafactor seq_len=64 with gradient checkpointing on versus off.

| Variant | Execution | Status | Avg tokens/sec | Last val loss | Peak CUDA MB | Failure | Complexity | Run dir |
| --- | --- | ---: | ---: | ---: | ---: | --- | --- | --- |
| `s64_b1_gc_on_3step_val` | train | `0` | 168.99 | 3.3519 | 10988/12324 |  | batch=1, grad_accum=1 (direct batch), seq_len=64, gradient_checkpointing=True | `/workspace/runs/deepseek-adafactor-s64-b1-gc-on-3step-val-20260620T110801Z` |
| `s64_b1_gc_off_3step_val` | train | `0` | 193.80 | 2.7425 | 11000/12512 |  | batch=1, grad_accum=1 (direct batch), seq_len=64, gradient_checkpointing=False | `/workspace/runs/deepseek-adafactor-s64-b1-gc-off-3step-val-20260620T110830Z` |

## Best Config Reasoning

- Selected variant: `s64_b1_gc_off_3step_val`
- Average tokens/sec: `193.80`
- Last validation loss: `2.7425`
- Reason: s64_b1_gc_off_3step_val is selected because it has the highest average tokens/sec among validation-sane candidates; validation loss 2.7425 is within 0.0% of the best observed 2.7425; complexity=batch=1, grad_accum=1 (direct batch), seq_len=64, gradient_checkpointing=False.
