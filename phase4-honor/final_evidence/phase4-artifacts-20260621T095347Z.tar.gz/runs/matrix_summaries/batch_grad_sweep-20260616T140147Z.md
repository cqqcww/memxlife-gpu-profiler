# Matrix Summary: batch_grad_sweep

Probe whether larger effective batches amortize per-step overhead.

| Variant | Status | Avg tokens/sec | Run dir |
| --- | ---: | ---: | --- |
| `bs2_ga1` | `0` | n/a | `` |
| `bs4_ga1` | `0` | n/a | `` |
| `bs8_ga1` | `0` | n/a | `` |
| `bs4_ga2` | `0` | n/a | `` |
