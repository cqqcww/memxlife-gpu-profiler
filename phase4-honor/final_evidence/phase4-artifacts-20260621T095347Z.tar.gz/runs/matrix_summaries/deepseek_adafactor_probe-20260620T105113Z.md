# Matrix Summary: deepseek_adafactor_probe

Probe whether the DeepSeek Adafactor low-memory path remains stable beyond a one-step smoke.

| Variant | Execution | Status | Avg tokens/sec | Last val loss | Failure | Complexity | Run dir |
| --- | --- | ---: | ---: | ---: | --- | --- | --- |
| `s16_b1_5step_val` | train | `0` | 47.38 | 10.8575 |  | batch=1, grad_accum=1 (direct batch), seq_len=16, gradient_checkpointing=True | `/workspace/runs/deepseek-adafactor-s16-b1-5step-val-20260620T105015Z` |
| `s32_b1_3step_val` | train | `0` | 84.54 | 10.8434 |  | batch=1, grad_accum=1 (direct batch), seq_len=32, gradient_checkpointing=True | `/workspace/runs/deepseek-adafactor-s32-b1-3step-val-20260620T105044Z` |

## Best Config Reasoning

- Selected variant: `s32_b1_3step_val`
- Average tokens/sec: `84.54`
- Last validation loss: `10.8434`
- Reason: s32_b1_3step_val is selected because it has the highest average tokens/sec among validation-sane candidates; validation loss 10.8434 is within 0.0% of the best observed 10.8434; complexity=batch=1, grad_accum=1 (direct batch), seq_len=32, gradient_checkpointing=True.
