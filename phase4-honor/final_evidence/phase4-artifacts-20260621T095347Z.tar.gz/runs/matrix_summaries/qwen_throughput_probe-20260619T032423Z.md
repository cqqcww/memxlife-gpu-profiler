# Matrix Summary: qwen_throughput_probe

Probe Qwen throughput bottlenecks by separating gradient checkpointing, batch size, and sequence length.

| Variant | Status | Avg tokens/sec | Last val loss | Complexity | Run dir |
| --- | ---: | ---: | ---: | --- | --- |
| `s64_b1_gc_on` | `1` | n/a | n/a | batch=1, grad_accum=1 (direct batch), seq_len=64, gradient_checkpointing=True | `/workspace/runs/qwen-probe-s64-b1-gc-on-20260619T032416Z` |
| `s64_b1_gc_off` | `1` | n/a | n/a | batch=1, grad_accum=1 (direct batch), seq_len=64, gradient_checkpointing=False | `/workspace/runs/qwen-probe-s64-b1-gc-off-20260619T032418Z` |
| `s64_b2_gc_off` | `1` | n/a | n/a | batch=2, grad_accum=1 (direct batch), seq_len=64, gradient_checkpointing=False | `/workspace/runs/qwen-probe-s64-b2-gc-off-20260619T032419Z` |
| `s128_b1_gc_off` | `1` | n/a | n/a | batch=1, grad_accum=1 (direct batch), seq_len=128, gradient_checkpointing=False | `/workspace/runs/qwen-probe-s128-b1-gc-off-20260619T032421Z` |
