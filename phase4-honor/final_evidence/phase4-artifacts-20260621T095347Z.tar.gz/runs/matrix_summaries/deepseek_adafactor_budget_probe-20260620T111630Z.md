# Matrix Summary: deepseek_adafactor_budget_probe

Compare two 128-token DeepSeek Adafactor shapes using a medium local corpus with enough blocks for batch_size=2.

| Variant | Execution | Status | Avg tokens/sec | Last val loss | Peak CUDA MB | Failure | Complexity | Run dir |
| --- | --- | ---: | ---: | ---: | ---: | --- | --- | --- |
| `s128_b1_gc_off_3step_val` | train | `0` | 385.16 | 9.9014 | 11020/12582 |  | batch=1, grad_accum=1 (direct batch), seq_len=128, gradient_checkpointing=False | `/workspace/runs/deepseek-adafactor-s128-b1-gc-off-3step-val-20260620T111533Z` |
| `s64_b2_gc_off_3step_val` | train | `0` | 385.81 | 10.0552 | 11020/12580 |  | batch=2, grad_accum=1 (direct batch), seq_len=64, gradient_checkpointing=False | `/workspace/runs/deepseek-adafactor-s64-b2-gc-off-3step-val-20260620T111601Z` |

## Best Config Reasoning

- Selected variant: `s64_b2_gc_off_3step_val`
- Average tokens/sec: `385.81`
- Last validation loss: `10.0552`
- Reason: s64_b2_gc_off_3step_val is selected because it has the highest average tokens/sec among validation-sane candidates; validation loss 10.0552 is within 1.6% of the best observed 9.9014; complexity=batch=2, grad_accum=1 (direct batch), seq_len=64, gradient_checkpointing=False.
