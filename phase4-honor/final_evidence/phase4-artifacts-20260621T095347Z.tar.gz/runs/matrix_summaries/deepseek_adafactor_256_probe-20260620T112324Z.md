# Matrix Summary: deepseek_adafactor_256_probe

Compare three 256-token DeepSeek Adafactor shapes on the medium local corpus.

| Variant | Execution | Status | Avg tokens/sec | Last val loss | Peak CUDA MB | Failure | Complexity | Run dir |
| --- | --- | ---: | ---: | ---: | ---: | --- | --- | --- |
| `s256_b1_gc_off_3step_val` | train | `0` | 756.78 | 9.5584 | 11060/12996 |  | batch=1, grad_accum=1 (direct batch), seq_len=256, gradient_checkpointing=False | `/workspace/runs/deepseek-adafactor-s256-b1-gc-off-3step-val-20260620T112158Z` |
| `s128_b2_gc_off_3step_val` | train | `0` | 756.23 | 9.9811 | 11060/12988 |  | batch=2, grad_accum=1 (direct batch), seq_len=128, gradient_checkpointing=False | `/workspace/runs/deepseek-adafactor-s128-b2-gc-off-3step-val-20260620T112226Z` |
| `s64_b4_gc_off_3step_val` | train | `0` | 759.65 | 10.7421 | 11060/13010 |  | batch=4, grad_accum=1 (direct batch), seq_len=64, gradient_checkpointing=False | `/workspace/runs/deepseek-adafactor-s64-b4-gc-off-3step-val-20260620T112255Z` |

## Best Config Reasoning

- Selected variant: `s256_b1_gc_off_3step_val`
- Average tokens/sec: `756.78`
- Last validation loss: `9.5584`
- Reason: s256_b1_gc_off_3step_val is selected because it has the highest average tokens/sec among validation-sane candidates; validation loss 9.5584 is within 0.0% of the best observed 9.5584; complexity=batch=1, grad_accum=1 (direct batch), seq_len=256, gradient_checkpointing=False.
