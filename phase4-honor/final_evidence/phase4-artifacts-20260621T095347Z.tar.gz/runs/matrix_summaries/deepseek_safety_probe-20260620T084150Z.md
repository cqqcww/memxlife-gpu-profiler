# Matrix Summary: deepseek_safety_probe

Stage DeepSeek through a safe preflight gate before the risky AdamW smoke step.

| Variant | Execution | Status | Avg tokens/sec | Last val loss | Failure | Complexity | Run dir |
| --- | --- | ---: | ---: | ---: | --- | --- | --- |
| `preflight_s16_b1` | preflight_only | `0` | n/a | n/a |  | batch=1, grad_accum=1 (direct batch), seq_len=16, gradient_checkpointing=True | `/workspace/runs/deepseek-matrix-preflight-s16-b1-20260620T084024Z` |
| `adamw_s16_b1` | train | `1` | n/a | n/a | cuda_oom | batch=1, grad_accum=1 (direct batch), seq_len=16, gradient_checkpointing=True | `/workspace/runs/deepseek-matrix-adamw-s16-b1-20260620T084053Z` |
| `adafactor_s16_b1_no_ckpt` | train | `0` | 18.52 | n/a |  | batch=1, grad_accum=1 (direct batch), seq_len=16, gradient_checkpointing=True | `/workspace/runs/deepseek-matrix-adafactor-s16-b1-no-ckpt-20260620T084122Z` |

## Best Config Reasoning

- Selected variant: `adafactor_s16_b1_no_ckpt`
- Average tokens/sec: `18.52`
- Last validation loss: `n/a`
- Reason: adafactor_s16_b1_no_ckpt is selected because it has the highest average tokens/sec among validation-sane candidates; validation loss was unavailable; complexity=batch=1, grad_accum=1 (direct batch), seq_len=16, gradient_checkpointing=True.
