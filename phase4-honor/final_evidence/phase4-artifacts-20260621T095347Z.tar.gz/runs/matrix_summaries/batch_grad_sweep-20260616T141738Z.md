# Matrix Summary: batch_grad_sweep

Probe whether larger effective batches amortize per-step overhead.

| Variant | Status | Avg tokens/sec | Run dir |
| --- | ---: | ---: | --- |
| `bs2_ga1` | `0` | 15089.89 | `/workspace/runs/sweep-bs2-ga1-20260616T141631Z` |
| `bs4_ga1` | `0` | 20321.91 | `/workspace/runs/sweep-bs4-ga1-20260616T141645Z` |
| `bs8_ga1` | `0` | 23958.34 | `/workspace/runs/sweep-bs8-ga1-20260616T141701Z` |
| `bs4_ga2` | `0` | 22090.97 | `/workspace/runs/sweep-bs4-ga2-20260616T141720Z` |
