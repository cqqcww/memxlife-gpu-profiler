# Agent Run Summary

- Run directory: `/workspace/runs/deepseek-realdata-wikitext-adafactor-tok512-20260621T071943Z`
- Train events: `3`
- Validation events: `1`
- Average tokens/sec: `1341.83`

## Last Train Metrics

```json
{
  "backward_s": 0.07527414290234447,
  "cuda_allocated_mb": 10594.74072265625,
  "cuda_peak_allocated_mb": 11144.458984375,
  "cuda_peak_reserved_mb": 13666.0,
  "cuda_reserved_mb": 13666.0,
  "data_s": 0.0003604448866099119,
  "forward_s": 0.04024092014878988,
  "loss": 10.340951919555664,
  "lr": 1e-05,
  "optimizer_s": 0.1806170609779656,
  "step_time_s": 0.2979880799539387,
  "tokens_per_sec": 1718.1895332160334
}
```

## Last Validation Metrics

```json
{
  "cuda_allocated_mb": 10849.7529296875,
  "cuda_peak_allocated_mb": 11172.630859375,
  "cuda_peak_reserved_mb": 13666.0,
  "cuda_reserved_mb": 13666.0,
  "loss": 9.818975194295247,
  "perplexity": 18379.20597147853
}
```
