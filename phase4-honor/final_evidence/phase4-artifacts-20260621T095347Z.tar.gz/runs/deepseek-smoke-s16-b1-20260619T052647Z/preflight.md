# Preflight Report

## Profiles

- Base config: `configs/base/causal_lm_debug.yaml`
- Model profile: `deepseek_placeholder`
- Data profile: `local_fixture`
- Notes: Small default base for profile-composed smoke runs. || model_profile: family=deepseek-causal-lm | expected_memory=high_or_unknown | Future/stretch target. Do not use as the main Phase 4 submission path. | Requires careful trust_remote_code, memory, tokenizer, and download checks. || data_profile: Tiny local file for smoke tests.

## Model And Data

- Model: `deepseek-ai/deepseek-coder-1.3b-base`
- Parameters: `1346471936`
- Data source: `local_text`
- Dataset/local path: `/workspace/fixtures/tiny_corpus.txt`
- Available columns: `['text']`
- Text field found: `True`
- Cache enabled: `True`

## Runtime

- Device: `cuda`
- Mixed precision: `auto`
- Tokens per optimizer step: `16`
- CUDA available: `True`

## Recommendations

- Estimated AdamW state is large relative to GPU memory; prefer smaller batch/seq_len, gradient accumulation, or a smaller model.

## Warnings

- trust_remote_code is enabled; this is acceptable for stretch profiles but should be explicit
