# Agent Run Summary

- Run directory: `/workspace/runs/debug-20260616T072839Z`
- Train events: `6`
- Validation events: `2`
- Average tokens/sec: `10107.15`

## Last Train Metrics

```json
{
  "backward_s": 0.00417457998264581,
  "data_s": 0.0005951450439170003,
  "forward_s": 0.003136029001325369,
  "loss": 10.828372955322266,
  "lr": 5e-05,
  "optimizer_s": 0.0012622589711099863,
  "step_time_s": 0.009599084965884686,
  "tokens_per_sec": 13334.604335195929
}
```

## Last Validation Metrics

```json
{
  "loss": 10.82474422454834,
  "perplexity": 50248.91454273136
}
```
