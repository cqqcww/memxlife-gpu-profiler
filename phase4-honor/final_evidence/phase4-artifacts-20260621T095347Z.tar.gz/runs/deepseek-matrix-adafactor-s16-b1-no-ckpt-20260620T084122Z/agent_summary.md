# Agent Run Summary

- Run directory: `/workspace/runs/deepseek-matrix-adafactor-s16-b1-no-ckpt-20260620T084122Z`
- Train events: `1`
- Validation events: `0`
- Average tokens/sec: `18.52`

## Last Train Metrics

```json
{
  "backward_s": 0.11156280199065804,
  "data_s": 0.0006077289581298828,
  "forward_s": 0.5158809958957136,
  "loss": 10.667044639587402,
  "lr": 0.0001,
  "optimizer_s": 0.23498192592523992,
  "step_time_s": 0.8638019359204918,
  "tokens_per_sec": 18.522764692521726
}
```

## Last Validation Metrics

```json
{}
```
