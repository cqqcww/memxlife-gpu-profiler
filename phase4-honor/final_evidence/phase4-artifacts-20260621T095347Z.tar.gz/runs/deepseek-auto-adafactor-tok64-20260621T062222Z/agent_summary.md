# Agent Run Summary

- Run directory: `/workspace/runs/deepseek-auto-adafactor-tok64-20260621T062222Z`
- Train events: `3`
- Validation events: `1`
- Average tokens/sec: `192.95`

## Last Train Metrics

```json
{
  "backward_s": 0.03960142796859145,
  "cuda_allocated_mb": 10453.23046875,
  "cuda_peak_allocated_mb": 11000.23046875,
  "cuda_peak_reserved_mb": 12512.0,
  "cuda_reserved_mb": 12512.0,
  "data_s": 0.0003028940409421921,
  "forward_s": 0.031944753136485815,
  "loss": 10.741555213928223,
  "lr": 1e-05,
  "optimizer_s": 0.18065215996466577,
  "step_time_s": 0.2537452098913491,
  "tokens_per_sec": 252.22151002339749
}
```

## Last Validation Metrics

```json
{
  "cuda_allocated_mb": 10485.232421875,
  "cuda_peak_allocated_mb": 11000.23046875,
  "cuda_peak_reserved_mb": 12512.0,
  "cuda_reserved_mb": 12512.0,
  "loss": 10.68773365020752,
  "perplexity": 43815.09405853122
}
```
