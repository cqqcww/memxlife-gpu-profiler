# Agent Run Summary

- Run directory: `/workspace/runs/deepseek-auto-adafactor-tok128-20260621T062253Z`
- Train events: `3`
- Validation events: `1`
- Average tokens/sec: `385.21`

## Last Train Metrics

```json
{
  "backward_s": 0.039228833047673106,
  "cuda_allocated_mb": 10473.10693359375,
  "cuda_peak_allocated_mb": 11020.10693359375,
  "cuda_peak_reserved_mb": 12582.0,
  "cuda_reserved_mb": 12582.0,
  "data_s": 0.00039207516238093376,
  "forward_s": 0.031924345064908266,
  "loss": 10.059154510498047,
  "lr": 1e-05,
  "optimizer_s": 0.18093221192248166,
  "step_time_s": 0.25374935707077384,
  "tokens_per_sec": 504.4347756290047
}
```

## Last Validation Metrics

```json
{
  "cuda_allocated_mb": 10537.1103515625,
  "cuda_peak_allocated_mb": 11020.10693359375,
  "cuda_peak_reserved_mb": 12582.0,
  "cuda_reserved_mb": 12582.0,
  "loss": 9.754542350769043,
  "perplexity": 17232.326573151844
}
```
