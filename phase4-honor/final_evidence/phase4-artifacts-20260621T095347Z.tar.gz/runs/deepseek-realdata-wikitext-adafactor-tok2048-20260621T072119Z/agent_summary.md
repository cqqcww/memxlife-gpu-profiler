# Agent Run Summary

- Run directory: `/workspace/runs/deepseek-realdata-wikitext-adafactor-tok2048-20260621T072119Z`
- Train events: `3`
- Validation events: `1`
- Average tokens/sec: `3100.38`

## Last Train Metrics

```json
{
  "backward_s": 0.2461565318517387,
  "cuda_allocated_mb": 11055.40087890625,
  "cuda_peak_allocated_mb": 14305.40185546875,
  "cuda_peak_reserved_mb": 18576.0,
  "cuda_reserved_mb": 18576.0,
  "data_s": 0.0005296601448208094,
  "forward_s": 0.1277604999486357,
  "loss": 9.217260360717773,
  "lr": 1e-05,
  "optimizer_s": 0.18064127815887332,
  "step_time_s": 0.556403324007988,
  "tokens_per_sec": 3680.783186641419
}
```

## Last Validation Metrics

```json
{
  "cuda_allocated_mb": 12075.4482421875,
  "cuda_peak_allocated_mb": 14305.40185546875,
  "cuda_peak_reserved_mb": 18828.0,
  "cuda_reserved_mb": 18828.0,
  "loss": 10.031954129536947,
  "perplexity": 22741.668318360265
}
```
