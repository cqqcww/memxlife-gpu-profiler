# Agent Run Summary

- Run directory: `/workspace/runs/sweep-bs8-ga1-20260616T143947Z`
- Train events: `12`
- Validation events: `2`
- Average tokens/sec: `23949.54`

## Last Train Metrics

```json
{
  "backward_s": 0.04759100894443691,
  "data_s": 0.00022945296950638294,
  "forward_s": 0.027107130037620664,
  "loss": 5.1964921951293945,
  "lr": 2.9999999999999997e-05,
  "optimizer_s": 0.00992431805934757,
  "step_time_s": 0.08523566299118102,
  "tokens_per_sec": 24027.501260967467
}
```

## Last Validation Metrics

```json
{
  "loss": 5.188016891479492,
  "perplexity": 179.11299998191646
}
```
