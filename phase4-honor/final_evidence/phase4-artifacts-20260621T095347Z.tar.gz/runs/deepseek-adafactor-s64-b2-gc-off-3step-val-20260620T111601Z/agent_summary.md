# Agent Run Summary

- Run directory: `/workspace/runs/deepseek-adafactor-s64-b2-gc-off-3step-val-20260620T111601Z`
- Train events: `3`
- Validation events: `1`
- Average tokens/sec: `385.81`

## Last Train Metrics

```json
{
  "backward_s": 0.03906413912773132,
  "cuda_allocated_mb": 10473.10693359375,
  "cuda_peak_allocated_mb": 11020.10693359375,
  "cuda_peak_reserved_mb": 12580.0,
  "cuda_reserved_mb": 12580.0,
  "data_s": 0.000454113120213151,
  "forward_s": 0.0317733739502728,
  "loss": 10.70743465423584,
  "lr": 1e-05,
  "optimizer_s": 0.18029115698300302,
  "step_time_s": 0.2527078799903393,
  "tokens_per_sec": 506.51368688975305
}
```

## Last Validation Metrics

```json
{
  "cuda_allocated_mb": 10504.98388671875,
  "cuda_peak_allocated_mb": 11020.10693359375,
  "cuda_peak_reserved_mb": 12580.0,
  "cuda_reserved_mb": 12580.0,
  "loss": 10.055158615112305,
  "perplexity": 23275.547270741736
}
```
