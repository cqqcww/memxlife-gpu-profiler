# Agent Run Summary

- Run directory: `/workspace/runs/deepseek-adafactor-s256-b1-gc-off-3step-val-20260620T112158Z`
- Train events: `3`
- Validation events: `1`
- Average tokens/sec: `756.78`

## Last Train Metrics

```json
{
  "backward_s": 0.04327238607220352,
  "cuda_allocated_mb": 10513.35986328125,
  "cuda_peak_allocated_mb": 11060.35986328125,
  "cuda_peak_reserved_mb": 12996.0,
  "cuda_reserved_mb": 12996.0,
  "data_s": 0.00056050019338727,
  "forward_s": 0.0329214739613235,
  "loss": 7.7178826332092285,
  "lr": 1e-05,
  "optimizer_s": 0.18047000793740153,
  "step_time_s": 0.25848117494024336,
  "tokens_per_sec": 990.4009452881163
}
```

## Last Validation Metrics

```json
{
  "cuda_allocated_mb": 10641.3662109375,
  "cuda_peak_allocated_mb": 11060.35986328125,
  "cuda_peak_reserved_mb": 12996.0,
  "cuda_reserved_mb": 12996.0,
  "loss": 9.558430671691895,
  "perplexity": 14163.60140883737
}
```
