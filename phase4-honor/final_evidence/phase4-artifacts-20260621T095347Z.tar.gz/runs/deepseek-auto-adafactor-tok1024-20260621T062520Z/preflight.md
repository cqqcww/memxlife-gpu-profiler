# Preflight Report

## Profiles

- Base config: `configs/base/causal_lm_debug.yaml`
- Model profile: `deepseek_placeholder`
- Data profile: `local_fixture`
- Notes: Small default base for profile-composed smoke runs. || model_profile: family=deepseek-causal-lm | expected_memory=high_or_unknown | Future/stretch target. Do not use as the main Phase 4 submission path. | Requires careful trust_remote_code, memory, tokenizer, and download checks. | Remote safety probe can build preflight artifacts, but full AdamW 1-step OOMs on RTX 3090 24GB. | Adafactor plus disabled checkpointing is validated through short 256-token probes on the RTX 3090. | Use --preflight-only unless a low-memory optimizer, offload, or smaller model path is intentionally enabled. || data_profile: Tiny local file for smoke tests.

## Model And Data

- Model: `deepseek-ai/deepseek-coder-1.3b-base`
- Parameters: `1346471936`
- Data source: `local_text`
- Dataset/local path: `/workspace/fixtures/medium_corpus.txt`
- Available columns: `['text']`
- Text field found: `True`
- Cache enabled: `True`

## Runtime

- Device: `cuda`
- Mixed precision: `auto`
- Tokens per optimizer step: `1024`
- CUDA available: `True`

## Recommendations

- Estimated AdamW state is large relative to GPU memory before activations and temporary optimizer buffers; prefer preflight-only, a low-memory optimizer, offload, smaller seq_len/batch_size, or a smaller model.
- If CUDA OOM occurs at this sequence length, try seq_len=256 or 128 for the smoke run.

## Warnings

- trust_remote_code is enabled; this is acceptable for stretch profiles but should be explicit
