# Agent Run Summary

- Run directory: `/workspace/runs/deepseek-auto-adafactor-tok1024-20260621T062520Z`
- Train events: `3`
- Validation events: `1`
- Average tokens/sec: `2135.06`

## Last Train Metrics

```json
{
  "backward_s": 0.13335419492796063,
  "cuda_allocated_mb": 10744.62744140625,
  "cuda_peak_allocated_mb": 11292.970703125,
  "cuda_peak_reserved_mb": 15140.0,
  "cuda_reserved_mb": 15140.0,
  "data_s": 0.0007160268723964691,
  "forward_s": 0.07095066900365055,
  "loss": 17.448862075805664,
  "lr": 1e-05,
  "optimizer_s": 0.18061104509979486,
  "step_time_s": 0.3869828088209033,
  "tokens_per_sec": 2646.112376722941
}
```

## Last Validation Metrics

```json
{
  "cuda_allocated_mb": 11254.6513671875,
  "cuda_peak_allocated_mb": 11388.52880859375,
  "cuda_peak_reserved_mb": 15140.0,
  "cuda_reserved_mb": 15140.0,
  "loss": 6.559964656829834,
  "perplexity": 706.2467331557913
}
```
