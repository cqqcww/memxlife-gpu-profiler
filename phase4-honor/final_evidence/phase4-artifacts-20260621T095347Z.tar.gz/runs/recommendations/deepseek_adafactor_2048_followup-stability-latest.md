# Stability Run Summary

- Status: `pass`
- Run directory: `/workspace/runs/deepseek-auto-adafactor-tok2048-stability-50step-20260621T063533Z`
- Source recommendation: `runs/recommendations/deepseek_adafactor_2048_followup-latest.json`
- Source variant: `tok2048`
- Source token budget: `2048`
- Completed train steps: `50/50`
- Logged train events: `10`
- Validation events: `5`
- Average tokens/sec: `3680.77`
- Last train loss: `0.06509650498628616`
- Last validation loss: `0.06078235059976578`
- Peak CUDA MB allocated/reserved: `14305/18576`

## Reasons

- No stability issues detected by the runner.
