# Agent Run Summary

- Run directory: `/workspace/runs/deepseek-auto-adafactor-tok2048-stability-50step-20260621T063309Z`
- Train events: `10`
- Validation events: `5`
- Average tokens/sec: `3684.04`

## Last Train Metrics

```json
{
  "backward_s": 0.2461565888952464,
  "cuda_allocated_mb": 11055.40087890625,
  "cuda_peak_allocated_mb": 14305.40185546875,
  "cuda_peak_reserved_mb": 18576.0,
  "cuda_reserved_mb": 18576.0,
  "data_s": 0.0005925919394940138,
  "forward_s": 0.1287804760504514,
  "loss": 0.06366946548223495,
  "lr": 1e-05,
  "optimizer_s": 0.180993810063228,
  "step_time_s": 0.5572086940519512,
  "tokens_per_sec": 3675.463110791045
}
```

## Last Validation Metrics

```json
{
  "cuda_allocated_mb": 12075.4482421875,
  "cuda_peak_allocated_mb": 14305.40185546875,
  "cuda_peak_reserved_mb": 18576.0,
  "cuda_reserved_mb": 18576.0,
  "loss": 0.06004628911614418,
  "perplexity": 1.0618856991581955
}
```
