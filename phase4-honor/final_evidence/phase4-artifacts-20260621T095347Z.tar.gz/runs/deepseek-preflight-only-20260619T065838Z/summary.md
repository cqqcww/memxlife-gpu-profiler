# Preflight Summary: deepseek-preflight-only

- Run directory: `/workspace/runs/deepseek-preflight-only-20260619T065838Z`
- Mode: `preflight_only`
- Parameters: `1346471936`
- Preflight: `/workspace/runs/deepseek-preflight-only-20260619T065838Z/preflight.json`

## Recommendations

- Estimated AdamW state is large relative to GPU memory before activations and temporary optimizer buffers; prefer preflight-only, a low-memory optimizer, offload, smaller seq_len/batch_size, or a smaller model.

## Warnings

- trust_remote_code is enabled; this is acceptable for stretch profiles but should be explicit
