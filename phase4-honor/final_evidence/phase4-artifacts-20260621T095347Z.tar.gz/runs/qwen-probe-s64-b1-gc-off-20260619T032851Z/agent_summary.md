# Agent Run Summary

- Run directory: `/workspace/runs/qwen-probe-s64-b1-gc-off-20260619T032851Z`
- Train events: `4`
- Validation events: `1`
- Average tokens/sec: `447.92`

## Last Train Metrics

```json
{
  "backward_s": 0.05144037492573261,
  "data_s": 0.00029246509075164795,
  "forward_s": 0.034332087030634284,
  "loss": 9.346986770629883,
  "lr": 0.0003,
  "optimizer_s": 0.05773504893295467,
  "step_time_s": 0.14471149700693786,
  "tokens_per_sec": 442.25926290384285
}
```

## Last Validation Metrics

```json
{
  "loss": 9.221814297267368,
  "perplexity": 10115.400032546884
}
```
