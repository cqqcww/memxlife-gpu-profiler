# Agent Run Summary

- Run directory: `/workspace/runs/sweep-bs8-ga1-20260616T141701Z`
- Train events: `12`
- Validation events: `2`
- Average tokens/sec: `23958.34`

## Last Train Metrics

```json
{
  "backward_s": 0.047723055933602154,
  "data_s": 0.00021408300381153822,
  "forward_s": 0.027239251066930592,
  "loss": 5.254622459411621,
  "lr": 2.9999999999999997e-05,
  "optimizer_s": 0.009928829036653042,
  "step_time_s": 0.08551292296033353,
  "tokens_per_sec": 23949.596494906342
}
```

## Last Validation Metrics

```json
{
  "loss": 5.132539315657183,
  "perplexity": 169.44685124227433
}
```
