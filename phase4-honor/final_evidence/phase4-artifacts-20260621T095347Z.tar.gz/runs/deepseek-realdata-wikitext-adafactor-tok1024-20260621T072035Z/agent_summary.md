# Agent Run Summary

- Run directory: `/workspace/runs/deepseek-realdata-wikitext-adafactor-tok1024-20260621T072035Z`
- Train events: `3`
- Validation events: `1`
- Average tokens/sec: `2137.52`

## Last Train Metrics

```json
{
  "backward_s": 0.13308321312069893,
  "cuda_allocated_mb": 10744.62744140625,
  "cuda_peak_allocated_mb": 11292.970703125,
  "cuda_peak_reserved_mb": 15140.0,
  "cuda_reserved_mb": 15140.0,
  "data_s": 0.0004170169122517109,
  "forward_s": 0.07067483896389604,
  "loss": 9.650527000427246,
  "lr": 1e-05,
  "optimizer_s": 0.18059801287017763,
  "step_time_s": 0.3860776820220053,
  "tokens_per_sec": 2652.315965628997
}
```

## Last Validation Metrics

```json
{
  "cuda_allocated_mb": 11254.6513671875,
  "cuda_peak_allocated_mb": 11898.65234375,
  "cuda_peak_reserved_mb": 15140.0,
  "cuda_reserved_mb": 15140.0,
  "loss": 10.798372404915947,
  "perplexity": 48941.08001588657
}
```
