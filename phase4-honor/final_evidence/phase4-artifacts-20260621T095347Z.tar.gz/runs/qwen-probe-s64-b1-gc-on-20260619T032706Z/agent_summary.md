# Agent Run Summary

- Run directory: `/workspace/runs/qwen-probe-s64-b1-gc-on-20260619T032706Z`
- Train events: `4`
- Validation events: `1`
- Average tokens/sec: `350.41`

## Last Train Metrics

```json
{
  "backward_s": 0.09009215887635946,
  "data_s": 0.00025500101037323475,
  "forward_s": 0.034050666028633714,
  "loss": NaN,
  "lr": 0.0003,
  "optimizer_s": 0.05752068292349577,
  "step_time_s": 0.18258681194856763,
  "tokens_per_sec": 350.5181963417379
}
```

## Last Validation Metrics

```json
{
  "loss": NaN,
  "perplexity": 485165195.4097903
}
```
