# Agent Run Summary

- Run directory: `/workspace/runs/deepseek-adafactor-s64-b1-gc-on-3step-val-20260620T110801Z`
- Train events: `3`
- Validation events: `1`
- Average tokens/sec: `168.99`

## Last Train Metrics

```json
{
  "backward_s": 0.07858505193144083,
  "cuda_allocated_mb": 10441.23046875,
  "cuda_peak_allocated_mb": 10988.23046875,
  "cuda_peak_reserved_mb": 12324.0,
  "cuda_reserved_mb": 12324.0,
  "data_s": 0.00036543491296470165,
  "forward_s": 0.03414081898517907,
  "loss": 5.513525485992432,
  "lr": 1e-05,
  "optimizer_s": 0.1803348190151155,
  "step_time_s": 0.2946553628426045,
  "tokens_per_sec": 217.20290234183437
}
```

## Last Validation Metrics

```json
{
  "cuda_allocated_mb": 10449.232421875,
  "cuda_peak_allocated_mb": 10988.23046875,
  "cuda_peak_reserved_mb": 12324.0,
  "cuda_reserved_mb": 12324.0,
  "loss": 3.3519399166107178,
  "perplexity": 28.558080236744175
}
```
