# Preflight Report

## Profiles

- Base config: `configs/base/causal_lm_debug.yaml`
- Model profile: `tiny_gpt2`
- Data profile: `local_fixture`
- Notes: Small default base for profile-composed smoke runs. || model_profile: family=gpt-style-causal-lm | expected_memory=tiny | Best for smoke tests only; not meaningful for model quality. || data_profile: Tiny local file for smoke tests.

## Model And Data

- Model: `sshleifer/tiny-gpt2`
- Parameters: `102714`
- Data source: `local_text`
- Dataset/local path: `/workspace/fixtures/tiny_corpus.txt`
- Cache enabled: `True`

## Runtime

- Device: `cuda`
- Mixed precision: `False`
- Tokens per optimizer step: `128`
- CUDA available: `True`

## Warnings

- none
