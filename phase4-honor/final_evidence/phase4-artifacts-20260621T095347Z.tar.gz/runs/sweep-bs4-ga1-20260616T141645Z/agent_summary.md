# Agent Run Summary

- Run directory: `/workspace/runs/sweep-bs4-ga1-20260616T141645Z`
- Train events: `12`
- Validation events: `2`
- Average tokens/sec: `20321.91`

## Last Train Metrics

```json
{
  "backward_s": 0.025160436984151602,
  "data_s": 0.0002150960499420762,
  "forward_s": 0.014795230003073812,
  "loss": 5.373619556427002,
  "lr": 2.9999999999999997e-05,
  "optimizer_s": 0.009913960006088018,
  "step_time_s": 0.05047672998625785,
  "tokens_per_sec": 20286.575621653406
}
```

## Last Validation Metrics

```json
{
  "loss": 5.370135352725074,
  "perplexity": 214.89195194726784
}
```
