# Agent Run Summary

- Run directory: `/workspace/runs/baseline-tinystories-20260616T090824Z`
- Train events: `20`
- Validation events: `4`
- Average tokens/sec: `27984.24`

## Last Train Metrics

```json
{
  "backward_s": 0.015585276996716857,
  "data_s": 0.0004127069842070341,
  "forward_s": 0.010420361999422312,
  "loss": 5.024968147277832,
  "lr": 2.9999999999999997e-05,
  "optimizer_s": 0.009827131987549365,
  "step_time_s": 0.03662646596785635,
  "tokens_per_sec": 27957.925312768908
}
```

## Last Validation Metrics

```json
{
  "loss": 4.93621792112078,
  "perplexity": 139.24262583740006
}
```
