# Agent Patch Proposal

- Observed bottleneck: optimizer overhead is large relative to forward time
- Proposed change: try a larger batch size or gradient accumulation sweep to amortize per-step overhead
- Expected effect: improve tokens/sec or reduce variance while keeping checkpoint/resume intact.
- Risk: added complexity may hide bugs in timing or resume behavior.
- Rollback: revert the proposed config/code change and rerun the previous stable config.
