# Agent Run Summary

- Run directory: `/workspace/runs/deepseek-auto-adafactor-tok2048-stability-50step-20260621T063533Z`
- Train events: `10`
- Validation events: `5`
- Average tokens/sec: `3680.77`

## Last Train Metrics

```json
{
  "backward_s": 0.24613194912672043,
  "cuda_allocated_mb": 11055.40087890625,
  "cuda_peak_allocated_mb": 14305.40185546875,
  "cuda_peak_reserved_mb": 18576.0,
  "cuda_reserved_mb": 18576.0,
  "data_s": 0.0005639900919049978,
  "forward_s": 0.12971425708383322,
  "loss": 0.06509650498628616,
  "lr": 1e-05,
  "optimizer_s": 0.18100655707530677,
  "step_time_s": 0.5580414941068739,
  "tokens_per_sec": 3669.9779884249524
}
```

## Last Validation Metrics

```json
{
  "cuda_allocated_mb": 12075.4482421875,
  "cuda_peak_allocated_mb": 14305.40185546875,
  "cuda_peak_reserved_mb": 18576.0,
  "cuda_reserved_mb": 18576.0,
  "loss": 0.06078235059976578,
  "perplexity": 1.0626676000496176
}
```
