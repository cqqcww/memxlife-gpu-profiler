# Stability Run Summary

- Status: `pass`
- Run directory: `/workspace/runs/deepseek-realdata-wikitext-adafactor-tok2048-stability-50step-20260621T072218Z`
- Source recommendation: `runs/recommendations/deepseek_adafactor_wikitext_realdata-latest.json`
- Source variant: `tok2048`
- Source token budget: `2048`
- Completed train steps: `50/50`
- Logged train events: `10`
- Validation events: `5`
- Average tokens/sec: `3655.35`
- Last train loss: `6.488150119781494`
- Last validation loss: `6.937769412994385`
- Peak CUDA MB allocated/reserved: `14305/18828`

## Reasons

- No stability issues detected by the runner.
