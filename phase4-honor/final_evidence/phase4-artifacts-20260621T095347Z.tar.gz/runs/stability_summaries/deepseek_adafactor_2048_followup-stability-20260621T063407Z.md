# Stability Run Summary

- Status: `fail`
- Run directory: `/workspace/runs/deepseek-auto-adafactor-tok2048-stability-50step-20260621T063309Z`
- Source recommendation: `runs/recommendations/deepseek_adafactor_2048_followup-latest.json`
- Source variant: `tok2048`
- Source token budget: `2048`
- Completed train steps: `10/50`
- Validation events: `5`
- Average tokens/sec: `3684.04`
- Last train loss: `0.06366946548223495`
- Last validation loss: `0.06004628911614418`
- Peak CUDA MB allocated/reserved: `14305/18576`

## Reasons

- completed 10/50 requested train steps
