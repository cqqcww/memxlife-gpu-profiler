# Agent Run Summary

- Run directory: `/workspace/runs/deepseek-adafactor-s128-b1-gc-off-3step-val-20260620T111533Z`
- Train events: `3`
- Validation events: `1`
- Average tokens/sec: `385.16`

## Last Train Metrics

```json
{
  "backward_s": 0.04006589716300368,
  "cuda_allocated_mb": 10473.10693359375,
  "cuda_peak_allocated_mb": 11020.10693359375,
  "cuda_peak_reserved_mb": 12582.0,
  "cuda_reserved_mb": 12582.0,
  "data_s": 0.00035503716208040714,
  "forward_s": 0.03212455799803138,
  "loss": 10.326156616210938,
  "lr": 1e-05,
  "optimizer_s": 0.18037832900881767,
  "step_time_s": 0.25422165798954666,
  "tokens_per_sec": 503.4976209826436
}
```

## Last Validation Metrics

```json
{
  "cuda_allocated_mb": 10537.1103515625,
  "cuda_peak_allocated_mb": 11020.10693359375,
  "cuda_peak_reserved_mb": 12582.0,
  "cuda_reserved_mb": 12582.0,
  "loss": 9.901357650756836,
  "perplexity": 19957.44729703966
}
```
