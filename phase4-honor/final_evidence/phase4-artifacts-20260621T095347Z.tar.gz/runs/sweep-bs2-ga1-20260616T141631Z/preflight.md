# Preflight Report

## Profiles

- Base config: `configs/cached_tinystories.yaml`
- Model profile: `none`
- Data profile: `none`
- Notes: none

## Model And Data

- Model: `distilgpt2`
- Parameters: `81912576`
- Data source: `huggingface_dataset`
- Dataset/local path: `roneneldan/TinyStories`
- Cache enabled: `True`

## Runtime

- Device: `cuda`
- Mixed precision: `off`
- Tokens per optimizer step: `512`
- CUDA available: `True`

## Warnings

- none
