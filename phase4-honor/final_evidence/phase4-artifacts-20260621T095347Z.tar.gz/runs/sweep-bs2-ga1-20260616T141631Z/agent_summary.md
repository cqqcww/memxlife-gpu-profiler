# Agent Run Summary

- Run directory: `/workspace/runs/sweep-bs2-ga1-20260616T141631Z`
- Train events: `12`
- Validation events: `2`
- Average tokens/sec: `15089.89`

## Last Train Metrics

```json
{
  "backward_s": 0.013896269025281072,
  "data_s": 0.00020333006978034973,
  "forward_s": 0.009399628965184093,
  "loss": 5.849157810211182,
  "lr": 2.9999999999999997e-05,
  "optimizer_s": 0.009840454091317952,
  "step_time_s": 0.03372068505268544,
  "tokens_per_sec": 15183.558673260864
}
```

## Last Validation Metrics

```json
{
  "loss": 5.69274930256169,
  "perplexity": 296.70824103554804
}
```
