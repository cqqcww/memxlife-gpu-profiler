# Auto Probe Recommendation: deepseek_adafactor_token_budget

Bounded DeepSeek Adafactor token-budget probe that expands until failure or a recommendation gate.

| Variant | Status | Tokens/step | Avg tokens/sec | Last val loss | Peak CUDA MB | Failure |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| `tok64` | `1` | 64 | n/a | n/a | n/a | missing_dependency |

## Recommendation

- Action: `fall_back`
- Selected token budget: `none`
- Next token budget: `n/a`
- Reason: No successful training probe completed. Start with preflight-only, lower token budget, or a lower-memory optimizer before retrying.
