# Auto Probe Recommendation: deepseek_adafactor_2048_followup

Follow-up probe requested by the 1024-token recommendation; test 2048 tokens/step only.

| Variant | Status | Tokens/step | Avg tokens/sec | Last val loss | Peak CUDA MB | Failure |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| `tok2048` | `0` | 2048 | 3092.42 | 3.5100 | 14305/18576 |  |

## Recommendation

- Action: `stability_run`
- Selected token budget: `2048`
- Next token budget: `n/a`
- Reason: `tok2048` is the best bounded safe point. Prefer a longer 50-100 step run before expanding further.
