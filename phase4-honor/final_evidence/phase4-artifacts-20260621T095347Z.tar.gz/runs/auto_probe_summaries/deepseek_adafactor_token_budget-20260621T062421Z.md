# Auto Probe Recommendation: deepseek_adafactor_token_budget

Bounded DeepSeek Adafactor token-budget probe that expands until failure or a recommendation gate.

| Variant | Status | Tokens/step | Avg tokens/sec | Last val loss | Peak CUDA MB | Failure |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| `tok64` | `0` | 64 | 192.95 | 10.6877 | 11000/12512 |  |
| `tok128` | `0` | 128 | 385.21 | 9.7545 | 11020/12582 |  |
| `tok256` | `0` | 256 | 755.79 | 10.1239 | 11060/12996 |  |
| `tok512` | `0` | 512 | 1343.92 | 8.6315 | 11144/13666 |  |

## Recommendation

- Action: `try_larger_budget`
- Selected token budget: `512`
- Next token budget: `1024`
- Reason: `tok512` is safe and reserved CUDA peak is 56% of the configured memory limit; try `1024` tokens/step next.
