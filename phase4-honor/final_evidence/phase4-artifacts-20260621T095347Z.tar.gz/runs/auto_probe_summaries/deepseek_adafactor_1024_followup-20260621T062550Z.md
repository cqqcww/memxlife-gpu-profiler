# Auto Probe Recommendation: deepseek_adafactor_1024_followup

Follow-up probe requested by the 512-token recommendation; test 1024 tokens/step only.

| Variant | Status | Tokens/step | Avg tokens/sec | Last val loss | Peak CUDA MB | Failure |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| `tok1024` | `0` | 1024 | 2135.06 | 6.5600 | 11389/15140 |  |

## Recommendation

- Action: `try_larger_budget`
- Selected token budget: `1024`
- Next token budget: `2048`
- Reason: `tok1024` is safe and reserved CUDA peak is 62% of the configured memory limit; try `2048` tokens/step next.
