# Agent Run Summary

- Run directory: `/workspace/runs/deepseek-realdata-wikitext-adafactor-tok2048-stability-100step-20260621T095155Z`
- Train events: `10`
- Validation events: `5`
- Average tokens/sec: `3650.34`

## Last Train Metrics

```json
{
  "backward_s": 0.25222667516209185,
  "cuda_allocated_mb": 11055.40087890625,
  "cuda_peak_allocated_mb": 14305.40185546875,
  "cuda_peak_reserved_mb": 18828.0,
  "cuda_reserved_mb": 18828.0,
  "data_s": 0.0004577601794153452,
  "forward_s": 0.13134189206175506,
  "loss": 6.3306779861450195,
  "lr": 1e-05,
  "optimizer_s": 0.18125030514784157,
  "step_time_s": 0.5658684079535306,
  "tokens_per_sec": 3619.216007139566
}
```

## Last Validation Metrics

```json
{
  "cuda_allocated_mb": 12075.4482421875,
  "cuda_peak_allocated_mb": 14305.40185546875,
  "cuda_peak_reserved_mb": 18828.0,
  "cuda_reserved_mb": 18828.0,
  "loss": 6.653914451599121,
  "perplexity": 775.8152807675357
}
```
