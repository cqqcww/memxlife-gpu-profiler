# Agent Run Summary

- Run directory: `/workspace/runs/deepseek-adafactor-s64-b1-gc-off-3step-val-20260620T110830Z`
- Train events: `3`
- Validation events: `1`
- Average tokens/sec: `193.80`

## Last Train Metrics

```json
{
  "backward_s": 0.038953120121732354,
  "cuda_allocated_mb": 10453.23046875,
  "cuda_peak_allocated_mb": 11000.23046875,
  "cuda_peak_reserved_mb": 12512.0,
  "cuda_reserved_mb": 12512.0,
  "data_s": 0.0005106159951537848,
  "forward_s": 0.03154296102002263,
  "loss": 5.806443214416504,
  "lr": 1e-05,
  "optimizer_s": 0.1801766820717603,
  "step_time_s": 0.2524000480771065,
  "tokens_per_sec": 253.56572032208345
}
```

## Last Validation Metrics

```json
{
  "cuda_allocated_mb": 10485.232421875,
  "cuda_peak_allocated_mb": 11000.23046875,
  "cuda_peak_reserved_mb": 12512.0,
  "cuda_reserved_mb": 12512.0,
  "loss": 2.742544651031494,
  "perplexity": 15.526444252539013
}
```
