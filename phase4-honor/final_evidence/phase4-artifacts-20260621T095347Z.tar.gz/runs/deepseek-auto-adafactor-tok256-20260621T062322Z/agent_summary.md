# Agent Run Summary

- Run directory: `/workspace/runs/deepseek-auto-adafactor-tok256-20260621T062322Z`
- Train events: `3`
- Validation events: `1`
- Average tokens/sec: `755.79`

## Last Train Metrics

```json
{
  "backward_s": 0.04380680713802576,
  "cuda_allocated_mb": 10513.35986328125,
  "cuda_peak_allocated_mb": 11060.35986328125,
  "cuda_peak_reserved_mb": 12996.0,
  "cuda_reserved_mb": 12996.0,
  "data_s": 0.0005579439457505941,
  "forward_s": 0.03265442792326212,
  "loss": 7.622588157653809,
  "lr": 1e-05,
  "optimizer_s": 0.18062591087073088,
  "step_time_s": 0.2588703038636595,
  "tokens_per_sec": 988.9121934002471
}
```

## Last Validation Metrics

```json
{
  "cuda_allocated_mb": 10641.3662109375,
  "cuda_peak_allocated_mb": 11060.35986328125,
  "cuda_peak_reserved_mb": 12996.0,
  "cuda_reserved_mb": 12996.0,
  "loss": 10.12389850616455,
  "perplexity": 24931.778311520808
}
```
