# Agent Run Summary

- Run directory: `/workspace/runs/qwen-probe-s64-b2-gc-off-20260619T032947Z`
- Train events: `4`
- Validation events: `1`
- Average tokens/sec: `897.67`

## Last Train Metrics

```json
{
  "backward_s": 0.05056475196033716,
  "data_s": 0.0003686239942908287,
  "forward_s": 0.0332848799880594,
  "loss": 9.016267776489258,
  "lr": 0.0003,
  "optimizer_s": 0.05752447806298733,
  "step_time_s": 0.14246852113865316,
  "tokens_per_sec": 898.4440841877476
}
```

## Last Validation Metrics

```json
{
  "loss": 8.943740313703364,
  "perplexity": 7659.7935732019605
}
```
