# Agent Run Summary

- Run directory: `/workspace/runs/deepseek-adafactor-s16-b1-5step-val-20260620T105015Z`
- Train events: `5`
- Validation events: `1`
- Average tokens/sec: `47.38`

## Last Train Metrics

```json
{
  "backward_s": 0.07840580213814974,
  "cuda_allocated_mb": 10435.32421875,
  "cuda_peak_allocated_mb": 10982.32421875,
  "cuda_peak_reserved_mb": 12288.0,
  "cuda_reserved_mb": 12288.0,
  "data_s": 0.00021316087804734707,
  "forward_s": 0.033354886109009385,
  "loss": 10.67082691192627,
  "lr": 1e-05,
  "optimizer_s": 0.1803609929047525,
  "step_time_s": 0.2935611489228904,
  "tokens_per_sec": 54.50312501741405
}
```

## Last Validation Metrics

```json
{
  "cuda_allocated_mb": 10437.294921875,
  "cuda_peak_allocated_mb": 10982.32421875,
  "cuda_peak_reserved_mb": 12288.0,
  "cuda_reserved_mb": 12288.0,
  "loss": 10.857507705688477,
  "perplexity": 51922.51061650049
}
```
