# Agent Run Summary

- Run directory: `/workspace/runs/sweep-bs4-ga2-20260616T141720Z`
- Train events: `12`
- Validation events: `2`
- Average tokens/sec: `22090.97`

## Last Train Metrics

```json
{
  "backward_s": 0.05267609399743378,
  "data_s": 0.00045931502245366573,
  "forward_s": 0.030108388047665358,
  "loss": 10.218986988067627,
  "lr": 2.9999999999999997e-05,
  "optimizer_s": 0.009884821949526668,
  "step_time_s": 0.09362975007388741,
  "tokens_per_sec": 21873.389583800363
}
```

## Last Validation Metrics

```json
{
  "loss": 5.104343845730736,
  "perplexity": 164.7359428690922
}
```
